function Y = process(X,k,anc,gamma,alpha,lambda)

% X n*d
nV = length(X);
t = anc;
Nt = length(t);
n = size(X{1},1);
weight = ones(1,nV);
sX = [n,k,nV];

%% initialization
for v = 1:nV
    X{v} = X{v};
    H{v} = zeros(n,k);
    J{v} = zeros(n,k);
    Q{v} = zeros(n,k);
    R{v} = eye(k);
end

Y = zeros(n,k);    

for p = 1:Nt
    for v = 1:nV
        Z{p,v} = zeros(n,t(p));
        A{p,v} = zeros(t(p),size(X{v},2));
    end
end

beta = zeros(1,p);
for p = 1:Nt
    W{p} = zeros(k,t(p));
    beta(p) = 1/Nt;
end
theta = ones(nV,1);

%% parameter setting 
iter=0;
mu = 10e-5;
pho_mu = 2;
max_mu = 10e10;
Isconverg = 0;
epson = 1e-6;
converge_H_J = [];

%% nonconvex setting
eta = 1;
ceta = 2;


%% Iteration 
while(Isconverg == 0)
% for iter = 1:200
    % ===============update Z =============================================
    for p = 1:Nt
        for v = 1:nV
            tmp = 2*gamma*X{v}*A{p,v}' + alpha*beta(p)*H{v}*W{p};
            [Zu,Zs,Zv] = svd(tmp,"econ");
            Z{p,v} = Zu*Zv';
        end
    end
    clear v;

    % ===============update H =============================================
    for v = 1:nV
        tmpH = zeros(n,k);
        for p = 1:Nt
            tmpH = tmpH + alpha*beta(p)*Z{p,v}*W{p}';
        end
        tmpH = tmpH - Q{v} + mu*J{v} + (2*lambda)*(1/theta(v))*Y*R{v}';
        [Hu,Hs,Hv] = svd(tmpH,"econ");
        H{v} = Hu*Hv';
    end

    % ===============update W =============================================
    for p = 1:Nt
        tmpW = zeros(k,t(p));
        for v = 1:nV
            tmpW = tmpW + H{v}'*Z{p,v};
        end
        [Wu,Ws,Wv] = svd(tmpW,"econ");
        W{p} = Wu*Wv';
    end

    % ===============update A =============================================
    for p = 1:Nt
        for v = 1:nV
            A{p,v} = Z{p,v}'*X{v};
        end
    end
    
    % ===============update J =============================================
    H_tensor = cat(3,H{:,:});
    Q_tensor = cat(3,Q{:,:});
    h = H_tensor(:);
    q = Q_tensor(:);

    [J_tensor,~] = wshrinkObj(h+1/mu*q,1/mu,sX,0,3);

    for v = 1:nV
        J{v} = J_tensor(:,:,v);
    end
    j = J_tensor(:);

    % ==============update beta ===========================================
    yita = zeros(1,Nt);
    for p = 1:Nt
        for v = 1:nV
            tmp = Z{p,v}'*H{v};
            yita(p) = yita(p) + trace(tmp*W{p});
        end
    end
    yita_sum = sqrt(sum(yita.^2));
    for p = 1:Nt
        beta(p) = yita(p)/yita_sum;
    end

    % ===============update Y =============================================
    sum_Y = zeros(size(Y));
    for v = 1:nV
        sum_Y = sum_Y + H{v}*R{v}/theta(v);
    end
  
    sum_Y = sum_Y;
    [~,y_idx] = max(sum_Y,[],2);
    Y = full(sparse(1:n,y_idx,ones(n,1),n,k));

    % ================update R ============================================
    for v = 1:nV
        [tmp_u,~,tmp_v] = svd(Y'*H{v});
        R{v} = tmp_v*tmp_u';
    end
    
    % ================update theta ========================================
    for v = 1:nV
        theta(v) = norm(Y-H{v}*R{v},'fro');
    end

    % ================update Lagrange multipliers =========================
    q = q + mu*(h-j);
    Q_tensor = reshape(q,sX);
    for v = 1:nV
        Q{v} = Q_tensor(:,:,v);
    end

    mu = min(mu*pho_mu, max_mu);

    % ================Convergence judgment ================================
    Isconverg = 1;
    max_H_J = 0;
    for v = 1:nV
        if (norm(H{v}-J{v},inf)>epson)
            history.norm_H_J = norm(H{v}-J{v},inf);
            % fprintf('    norm_H_J %7.10f \n', history.norm_H_J);
            max_H_J = max(max_H_J,history.norm_H_J);
            Isconverg = 0;
        end
    end

    converge_H_J = [converge_H_J max_H_J];

    RE(iter+1) = max_H_J;


    % if (iter>50)
    %     Isconverg = 1;
    % end
    iter = iter + 1;
end

fprintf("%d",iter);

%% Return clustering indicator matrix
[~,Y] = max(Y,[],2);

end




























