clc;
clear;
addpath('../func');
addpath('../dataset');
addpath('../');

%% load dataeset
load('ORL.mat');
Dataname = 'ORL';

%% data preprocess
X = X;
gt = gt;
nV = length(X);
k = length(unique(gt));
n = size(X{1},1);
X{1} = X{1,1}'; X{2} = X{1,2}'; X{3} = X{1,3}'; 

%% data normalization
for v = 1:nV
    [X{v}] = NormalizeFea(X{v});
end

%% parameter setting
% gam = [0.0001,0.001,0.01,0.1,1,10];
% alp = [0.0001,0.001,0.01,0.1,1,10];
% lam = [0.0001,0.001,0.01,0.1,1,10];

gam = [1];
alp = [0.1];
lam = [0.01];
% anchor = [  1*k, 3*k, 5*k; 
%             2*k, 4*k, 6*k; 
%             3*k, 5*k, 7*k; 
%             4*k, 6*k, 8*k; 
%             5*k, 7*k, 9*k; 
%             6*k, 8*k, 10*k
%          ];

anchor = [1*k, 3*k, 5*k];

%% initialize variable




%% main process
for i = 1:size(anchor,1)
    anc = anchor(i,:);
    disp(anc);
    R = [];
    para = [];
    r = [];
    MaxAcc = 0;
    for gamma = gam
        for alpha = alp
            for lambda = lam
                % for p = lp
                    runtime = [];
                    tic;
                    Y1 = process(X,k,anc,gamma,alpha,lambda); 
                    % Y1 = process(X,k,anc,gamma,alpha,lambda,p); 
                    runtime = [runtime,toc];
                    for iv = 1:2
                        [ACC,NMI,PUR] = ClusteringMeasure(gt,Y1);
                        [Fscore,Precision,Recall] = compute_f(gt,Y1);
                        res(iv,:) = [ACC NMI PUR Fscore Precision Recall];
                    end
                    
                    resm = mean(res)*100;
                    stdm = std(res)*100;
                    restime = mean(runtime);
    
                    R = [R;resm,stdm,restime];
                    para = [para;gamma,alpha,lambda];
    
                    if (MaxAcc < resm(1))
                        MaxAcc = resm(1);
                    end
                    
                    fprintf("gamma = %f, alpha = %f, lambda = %f ACC = %f MaxACC = %f time = %f\n", gamma, alpha, lambda,resm(1),MaxAcc,restime);
    
                    r = [para,R];
    
                    % 创建一个文件夹用于存储结果
                    folder_path = '../res_test_opt';
                    if ~exist(folder_path, 'dir')
                        mkdir(folder_path);
                    end
        
                    % 创建以databname为名的子文件夹
                    subfolder_name = Dataname; % 假设databname是一个变量，包含你想要创建的子文件夹的名称
                    subfolder_path = fullfile(folder_path, subfolder_name);
                    if ~exist(subfolder_path, 'dir')
                        mkdir(subfolder_path);
                    end
        
                    % 创建文件名，保存数组
                    file_name = sprintf('%s_%d_%d_%d.mat', Dataname,anc(1)/k,anc(2)/k,anc(3)/k);
                    file_path = fullfile(subfolder_path, file_name);
    
                    % 保存数组到 .mat 文件
                    save(file_path, 'r');
    
    
                % end
            end
        end
    end
end

[m,n] = max(r(:,4))
r(n,:)
